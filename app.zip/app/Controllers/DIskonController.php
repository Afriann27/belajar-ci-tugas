<?php

namespace App\Controllers;

use App\Models\DiskonModel;
use CodeIgniter\Controller;

class DiskonController extends BaseController
{
    protected $diskon;

    public function __construct()
    {
        $this->diskon = new DiskonModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        if (session('role') != 'admin') return redirect()->to('/');
        $data['diskon'] = $this->diskon->orderBy('tanggal', 'ASC')->findAll();
        return view('diskon/index', $data);
    }

    public function create()
    {
        if (session('role') != 'admin') return redirect()->to('/');
        return view('diskon/create');
    }

    public function store()
    {
        if (session('role') != 'admin') return redirect()->to('/');

        $tanggal = $this->request->getPost('tanggal');

        // Validasi tanggal unik
        $existing = $this->diskon->where('tanggal', $tanggal)->first();
        if ($existing) {
            return redirect()->back()->withInput()->with('error', 'Diskon untuk tanggal ini sudah ada.');
        }

        $this->diskon->save([
            'tanggal' => $tanggal,
            'nominal' => $this->request->getPost('nominal'),
        ]);

        return redirect()->to('/diskon')->with('success', 'Diskon berhasil ditambahkan.');
    }

    public function edit($id)
    {
        if (session('role') != 'admin') return redirect()->to('/');
        $data['diskon'] = $this->diskon->find($id);
        return view('diskon/edit', $data);
    }

    public function update($id)
    {
        if (session('role') != 'admin') return redirect()->to('/');

        $this->diskon->update($id, [
            'nominal' => $this->request->getPost('nominal'),
        ]);

        return redirect()->to('/diskon')->with('success', 'Diskon berhasil diupdate.');
    }

    public function delete($id)
    {
        if (session('role') != 'admin') return redirect()->to('/');
        $this->diskon->delete($id);
        return redirect()->to('/diskon')->with('success', 'Diskon berhasil dihapus.');
    }
}
