<?= session()->getFlashdata('success') ?>
<a href="/diskon/create">Tambah Diskon</a>
<table>
    <tr>
        <th>Tanggal</th><th>Nominal</th><th>Aksi</th>
    </tr>
    <?php foreach ($diskon as $d): ?>
    <tr>
        <td><?= $d['tanggal'] ?></td>
        <td>Rp<?= number_format($d['nominal']) ?></td>
        <td>
            <a href="/diskon/edit/<?= $d['id'] ?>">Edit</a> |
            <a href="/diskon/delete/<?= $d['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
